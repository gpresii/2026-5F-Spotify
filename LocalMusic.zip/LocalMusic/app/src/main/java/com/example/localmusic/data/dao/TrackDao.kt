package com.example.localmusic.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.localmusic.data.Track
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackDao {

    @Insert
    suspend fun insertTrack(track: Track)

    @Query("SELECT * FROM tracks ORDER BY id DESC")
    fun getAllTracks(): Flow<List<Track>>

    @Query(
        """
        UPDATE tracks
        SET title = :title,
            artist = :artist,
            album = :album,
            year = :year
        WHERE id = :id
        """
    )
    suspend fun updateMetadata(
        id: Int,
        title: String?,
        artist: String?,
        album: String?,
        year: String?
    )

    @Query(
        """
        UPDATE tracks
        SET isFavorite = NOT isFavorite
        WHERE id = :id
        """
    )
    suspend fun toggleFavorite(
        id: Int
    )
}