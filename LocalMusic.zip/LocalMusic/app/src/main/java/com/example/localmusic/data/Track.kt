package com.example.localmusic.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class Track(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val fileName: String,
    val uri: String,

    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    val year: String? = null,

    val artworkPath: String? = null,

    val isFavorite: Boolean = false
)