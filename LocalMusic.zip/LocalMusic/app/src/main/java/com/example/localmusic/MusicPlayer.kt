package com.example.localmusic

import android.content.Context
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class MusicPlayer(context: Context) {

    private val player =
        ExoPlayer.Builder(context).build()

    private val scope =
        CoroutineScope(Dispatchers.Main)

    private var progressJob: Job? = null

    private val _isPlaying =
        MutableStateFlow(false)

    val isPlaying: StateFlow<Boolean> =
        _isPlaying

    private val _position =
        MutableStateFlow(0L)

    val position: StateFlow<Long> =
        _position

    private val _duration =
        MutableStateFlow(0L)

    val duration: StateFlow<Long> =
        _duration

    init {

        val audioAttributes =
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(
                    C.AUDIO_CONTENT_TYPE_MUSIC
                )
                .build()

        player.setAudioAttributes(
            audioAttributes,
            true
        )

        player.addListener(
            object : Player.Listener {

                override fun onIsPlayingChanged(
                    isPlaying: Boolean
                ) {

                    _isPlaying.value =
                        isPlaying

                    if (isPlaying) {
                        startProgressUpdates()
                    } else {
                        stopProgressUpdates()
                        updateProgress()
                    }
                }

                override fun onPlaybackStateChanged(
                    playbackState: Int
                ) {

                    updateProgress()

                    if (
                        playbackState ==
                        Player.STATE_ENDED
                    ) {

                        _isPlaying.value =
                            false

                        stopProgressUpdates()
                    }
                }

                override fun onMediaItemTransition(
                    mediaItem: MediaItem?,
                    reason: Int
                ) {

                    updateProgress()
                }

                override fun onPlayerError(
                    error: PlaybackException
                ) {

                    error.printStackTrace()

                    println(
                        "LOCALMUSIC ERROR: " +
                                error.errorCodeName
                    )

                    println(
                        "LOCALMUSIC ERROR MESSAGE: " +
                                error.message
                    )
                }
            }
        )
    }

    fun play(path: String) {

        val file = File(path)

        if (!file.exists()) {

            println(
                "LOCALMUSIC ERROR: " +
                        "plik nie istnieje: $path"
            )

            return
        }

        if (file.length() == 0L) {

            println(
                "LOCALMUSIC ERROR: " +
                        "plik jest pusty: $path"
            )

            return
        }

        println(
            "LOCALMUSIC: odtwarzam plik: $path"
        )

        println(
            "LOCALMUSIC: rozmiar pliku: " +
                    "${file.length()} bajtów"
        )

        val fileUri =
            Uri.fromFile(file)

        println(
            "LOCALMUSIC: URI: $fileUri"
        )

        val mediaItem =
            MediaItem.fromUri(fileUri)

        player.setMediaItem(mediaItem)

        player.prepare()

        player.play()
    }

    fun togglePlayPause() {

        if (player.isPlaying) {

            player.pause()

        } else {

            player.play()
        }
    }

    fun seekTo(position: Long) {

        player.seekTo(position)

        updateProgress()
    }

    fun updateProgress() {

        _position.value =
            player.currentPosition

        _duration.value =
            player.duration.coerceAtLeast(0L)

        _isPlaying.value =
            player.isPlaying
    }

    private fun startProgressUpdates() {

        if (progressJob?.isActive == true) {
            return
        }

        progressJob =
            scope.launch {

                while (isActive) {

                    updateProgress()

                    delay(250)
                }
            }
    }

    private fun stopProgressUpdates() {

        progressJob?.cancel()

        progressJob = null
    }

    fun release() {

        stopProgressUpdates()

        player.release()

        scope.cancel()
    }
}