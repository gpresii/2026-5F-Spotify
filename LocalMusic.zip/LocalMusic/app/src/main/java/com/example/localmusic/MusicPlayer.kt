
package com.example.localmusic

import android.content.Context
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

class MusicPlayer(context: Context) {

    private val player = ExoPlayer.Builder(context.applicationContext).build()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var progressJob: Job? = null
    private var queuePaths: List<String> = emptyList()

    private val _queue = MutableStateFlow<List<String>>(emptyList())
    val queue: StateFlow<List<String>> = _queue

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _position = MutableStateFlow(0L)
    val position: StateFlow<Long> = _position

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration

    private val _currentPath = MutableStateFlow<String?>(null)
    val currentPath: StateFlow<String?> = _currentPath

    init {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        player.setAudioAttributes(audioAttributes, true)

        player.addListener(object : Player.Listener {

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying

                if (isPlaying) {
                    startProgressUpdates()
                } else {
                    stopProgressUpdates()
                    updateProgress()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                updateProgress()

                if (playbackState == Player.STATE_ENDED) {
                    _isPlaying.value = false
                    stopProgressUpdates()
                }
            }

            override fun onMediaItemTransition(
                mediaItem: MediaItem?,
                reason: Int
            ) {
                _currentPath.value =
                    queuePaths.getOrNull(player.currentMediaItemIndex)

                updateProgress()
            }

            override fun onPlayerError(error: PlaybackException) {
                error.printStackTrace()
                println("LOCALMUSIC ERROR: ${error.errorCodeName}")
                println("LOCALMUSIC ERROR MESSAGE: ${error.message}")

                _isPlaying.value = false
                stopProgressUpdates()
            }
        })
    }

    fun play(path: String) {
        val file = File(path)

        if (!file.exists() || file.length() == 0L) {
            println("LOCALMUSIC ERROR: plik nie istnieje lub jest pusty: $path")
            return
        }

        if (_currentPath.value == path) {
            if (player.playbackState == Player.STATE_ENDED) {
                player.seekTo(0L)
            }
            player.play()
            return
        }

        playQueue(listOf(path), 0)
    }

    fun playQueue(paths: List<String>, startIndex: Int) {
        val requestedPath = paths.getOrNull(startIndex)

        val validPaths = paths.filter { path ->
            val file = File(path)
            file.exists() && file.length() > 0L
        }

        if (validPaths.isEmpty()) {
            println("LOCALMUSIC ERROR: brak poprawnych plików w kolejce")
            return
        }

        val safeStartIndex = validPaths.indexOf(requestedPath)
            .takeIf { it >= 0 } ?: 0

        queuePaths = validPaths
        _queue.value = validPaths
        _currentPath.value = validPaths[safeStartIndex]

        val mediaItems = validPaths.map { path ->
            MediaItem.fromUri(Uri.fromFile(File(path)))
        }

        player.setMediaItems(mediaItems, safeStartIndex, 0L)
        player.prepare()
        player.play()
    }

    /**
     * Odtwarza utwór wskazany indeksem na aktualnej liście kolejki.
     */
    fun playQueueItem(index: Int) {
        val paths = queuePaths
        if (index !in paths.indices) return

        playQueue(paths, index)
    }

    /**
     * Usuwa utwór z kolejki.
     * Gdy usuwany jest aktualnie odtwarzany utwór,
     * odtwarzacz przechodzi do kolejnego, jeśli istnieje.
     */
    fun removeFromQueue(index: Int) {
        if (index !in queuePaths.indices) return

        val currentIndex = player.currentMediaItemIndex

        if (queuePaths.size == 1) {
            queuePaths = emptyList()
            _queue.value = emptyList()

            player.clearMediaItems()
            _currentPath.value = null
            _position.value = 0L
            _duration.value = 0L
            _isPlaying.value = false
            stopProgressUpdates()
            return
        }

        player.removeMediaItem(index)

        queuePaths = queuePaths.toMutableList().apply {
            removeAt(index)
        }
        _queue.value = queuePaths

        if (index == currentIndex) {
            _currentPath.value =
                queuePaths.getOrNull(player.currentMediaItemIndex)
        } else {
            _currentPath.value =
                queuePaths.getOrNull(player.currentMediaItemIndex)
        }

        updateProgress()
    }

    /**
     * Przesuwa utwór na inne miejsce kolejki.
     */
    fun moveQueueItem(fromIndex: Int, toIndex: Int) {
        if (fromIndex !in queuePaths.indices) return
        if (toIndex !in queuePaths.indices) return
        if (fromIndex == toIndex) return

        player.moveMediaItem(fromIndex, toIndex)

        queuePaths = queuePaths.toMutableList().apply {
            val item = removeAt(fromIndex)
            add(toIndex, item)
        }

        _queue.value = queuePaths
        _currentPath.value =
            queuePaths.getOrNull(player.currentMediaItemIndex)
    }

    fun togglePlayPause() {
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_ENDED) {
                player.seekTo(0L)
            }
            if (player.mediaItemCount > 0) {
                player.play()
            }
        }
    }

    fun skipToNext() {
        if (player.hasNextMediaItem()) {
            player.seekToNextMediaItem()
            player.play()
        }
    }

    fun skipToPrevious() {
        if (player.currentPosition > 3000L) {
            player.seekTo(0L)
            updateProgress()
        } else if (player.hasPreviousMediaItem()) {
            player.seekToPreviousMediaItem()
            player.play()
        } else {
            player.seekTo(0L)
            updateProgress()
        }
    }

    fun seekTo(position: Long) {
        player.seekTo(position.coerceAtLeast(0L))
        updateProgress()
    }

    fun updateProgress() {
        _position.value = player.currentPosition.coerceAtLeast(0L)

        _duration.value =
            if (player.duration == C.TIME_UNSET) {
                0L
            } else {
                player.duration.coerceAtLeast(0L)
            }

        _isPlaying.value = player.isPlaying
    }

    private fun startProgressUpdates() {
        if (progressJob?.isActive == true) return

        progressJob = scope.launch {
            while (isActive) {
                updateProgress()
                delay(250)
            }
        }
    }

    private fun stopProgressUpdates() {
        progressJob?.cancel()
        progressJob = null
    }

    fun release() {
        stopProgressUpdates()
        player.release()
        scope.cancel()
    }
}
