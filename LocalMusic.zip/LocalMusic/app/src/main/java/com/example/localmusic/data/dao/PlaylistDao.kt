package com.example.localmusic.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.localmusic.data.Playlist
import com.example.localmusic.data.PlaylistTrack
import com.example.localmusic.data.Track
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {

    // Pobieranie wszystkich playlist
    @Query(
        "SELECT * FROM playlists ORDER BY id DESC"
    )
    fun getAllPlaylists(): Flow<List<Playlist>>

    // Tworzenie playlisty
    @Insert
    suspend fun insertPlaylist(
        playlist: Playlist
    ): Long

    // Zmiana nazwy playlisty
    @Query(
        "UPDATE playlists SET name = :name WHERE id = :playlistId"
    )
    suspend fun renamePlaylist(
        playlistId: Int,
        name: String
    )

    // Usuwanie playlisty
    @Query(
        "DELETE FROM playlists WHERE id = :playlistId"
    )
    suspend fun deletePlaylist(
        playlistId: Int
    )

    // Dodawanie utworu do playlisty
    // IGNORE zapobiega błędowi, gdy utwór już tam jest
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addTrackToPlaylist(
        playlistTrack: PlaylistTrack
    )

    // Pobieranie utworów należących do playlisty
    @Query(
        """
        SELECT tracks.*
        FROM tracks
        INNER JOIN playlist_tracks
            ON tracks.id = playlist_tracks.trackId
        WHERE playlist_tracks.playlistId = :playlistId
        ORDER BY playlist_tracks.rowid ASC
        """
    )
    fun getTracksInPlaylist(
        playlistId: Int
    ): Flow<List<Track>>

    // Usuwanie pojedynczego utworu z playlisty
    @Query(
        """
        DELETE FROM playlist_tracks
        WHERE playlistId = :playlistId
          AND trackId = :trackId
        """
    )
    suspend fun removeTrackFromPlaylist(
        playlistId: Int,
        trackId: Int
    )

    // Usuwanie powiązań przed skasowaniem playlisty
    @Query(
        """
        DELETE FROM playlist_tracks
        WHERE playlistId = :playlistId
        """
    )
    suspend fun removeAllTracksFromPlaylist(
        playlistId: Int
    )
}