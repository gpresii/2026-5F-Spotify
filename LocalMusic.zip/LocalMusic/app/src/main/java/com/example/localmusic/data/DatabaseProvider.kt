package com.example.localmusic.data

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

object DatabaseProvider {

    private val MIGRATION_1_2 =
        object : Migration(1, 2) {

            override fun migrate(
                database: SupportSQLiteDatabase
            ) {

                database.execSQL(
                    "ALTER TABLE tracks ADD COLUMN title TEXT"
                )

                database.execSQL(
                    "ALTER TABLE tracks ADD COLUMN artist TEXT"
                )

                database.execSQL(
                    "ALTER TABLE tracks ADD COLUMN album TEXT"
                )

                database.execSQL(
                    "ALTER TABLE tracks ADD COLUMN year TEXT"
                )

                database.execSQL(
                    "ALTER TABLE tracks ADD COLUMN artworkPath TEXT"
                )
            }
        }

    private val MIGRATION_2_3 =
        object : Migration(2, 3) {

            override fun migrate(
                database: SupportSQLiteDatabase
            ) {

                database.execSQL(
                    """
                    ALTER TABLE tracks
                    ADD COLUMN isFavorite INTEGER NOT NULL DEFAULT 0
                    """.trimIndent()
                )
            }
        }

    @Volatile
    private var INSTANCE: LocalMusicDatabase? = null

    fun getDatabase(
        context: Context
    ): LocalMusicDatabase {

        return INSTANCE
            ?: synchronized(this) {

                INSTANCE
                    ?: Room.databaseBuilder(
                        context.applicationContext,
                        LocalMusicDatabase::class.java,
                        "local_music.db"
                    )
                        .addMigrations(
                            MIGRATION_1_2,
                            MIGRATION_2_3
                        )
                        .build()
                        .also {
                            INSTANCE = it
                        }
            }
    }
}