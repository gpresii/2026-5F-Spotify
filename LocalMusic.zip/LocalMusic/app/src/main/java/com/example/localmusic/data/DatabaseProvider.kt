package com.example.localmusic.data

import android.content.Context
import androidx.room.Room

object DatabaseProvider {

    @Volatile
    private var INSTANCE: LocalMusicDatabase? = null

    fun getDatabase(context: Context): LocalMusicDatabase {
        return INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                LocalMusicDatabase::class.java,
                "local_music.db"
            ).build().also {
                INSTANCE = it
            }
        }
    }
}