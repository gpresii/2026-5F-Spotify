package com.example.localmusic

import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.localmusic.data.DatabaseProvider
import com.example.localmusic.data.Track
import com.example.localmusic.ui.theme.LocalMusicTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {

    private var tracks by mutableStateOf<List<Track>>(emptyList())
    private var selectedTrack by mutableStateOf<Track?>(null)

    private val database by lazy {
        DatabaseProvider.getDatabase(applicationContext)
    }

    private val musicPlayer by lazy {
        MusicPlayer(applicationContext)
    }

    private val pickAudio =
        registerForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->

            if (uri != null) {

                CoroutineScope(Dispatchers.IO).launch {

                    try {

                        val fileName = getFileName(uri)

                        val musicDirectory = File(
                            filesDir,
                            "music"
                        )

                        if (!musicDirectory.exists()) {
                            musicDirectory.mkdirs()
                        }

                        val safeFileName = fileName
                            .replace("/", "_")
                            .replace("\\", "_")

                        val destinationFile = File(
                            musicDirectory,
                            "${System.currentTimeMillis()}_$safeFileName"
                        )

                        contentResolver.openInputStream(uri)?.use { input ->

                            destinationFile.outputStream().use { output ->
                                input.copyTo(output)
                            }
                        }

                        if (!destinationFile.exists() ||
                            destinationFile.length() == 0L
                        ) {
                            return@launch
                        }

                        val track = Track(
                            fileName = fileName,
                            uri = destinationFile.absolutePath
                        )

                        database.trackDao().insertTrack(track)

                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

    private fun getFileName(uri: Uri): String {

        var fileName = "Nieznany utwór"

        val cursor: Cursor? = contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )

        cursor?.use {

            if (it.moveToFirst()) {

                val nameIndex =
                    it.getColumnIndex(OpenableColumns.DISPLAY_NAME)

                if (nameIndex >= 0) {
                    fileName = it.getString(nameIndex)
                }
            }
        }

        return fileName
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        CoroutineScope(Dispatchers.IO).launch {

            database.trackDao()
                .getAllTracks()
                .collectLatest { trackList ->

                    tracks = trackList
                }
        }

        setContent {

            LocalMusicTheme {

                LocalMusicApp(
                    tracks = tracks,
                    selectedTrack = selectedTrack,
                    musicPlayer = musicPlayer,

                    onTrackClick = { track ->
                        selectedTrack = track
                    },

                    onBack = {
                        selectedTrack = null
                    },

                    onPlay = { track ->
                        musicPlayer.play(track.uri)
                    },

                    onAddTrack = {
                        pickAudio.launch(
                            arrayOf("audio/mpeg")
                        )
                    }
                )
            }
        }
    }

    override fun onDestroy() {

        musicPlayer.release()

        super.onDestroy()
    }
}

@Composable
fun LocalMusicApp(
    tracks: List<Track>,
    selectedTrack: Track?,
    musicPlayer: MusicPlayer,
    onTrackClick: (Track) -> Unit,
    onBack: () -> Unit,
    onPlay: (Track) -> Unit,
    onAddTrack: () -> Unit
) {

    Scaffold(
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->

        if (selectedTrack == null) {

            LibraryScreen(
                tracks = tracks,
                onTrackClick = onTrackClick,
                onAddTrack = onAddTrack,
                modifier = Modifier.padding(innerPadding)
            )

        } else {

            TrackDetailsScreen(
                track = selectedTrack,
                musicPlayer = musicPlayer,
                onBack = onBack,
                onPlay = onPlay,
                modifier = Modifier.padding(innerPadding)
            )
        }
    }
}

@Composable
fun LibraryScreen(
    tracks: List<Track>,
    onTrackClick: (Track) -> Unit,
    onAddTrack: () -> Unit,
    modifier: Modifier = Modifier
) {

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = "LocalMusic"
            )

            Button(
                onClick = onAddTrack
            ) {
                Text("Dodaj utwór")
            }
        }

        if (tracks.isEmpty()) {

            Text(
                text = "Twoja biblioteka muzyczna jest pusta.",
                modifier = Modifier.padding(top = 32.dp)
            )

        } else {

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp)
            ) {

                items(tracks) { track ->

                    Text(
                        text = track.fileName,

                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onTrackClick(track)
                            }
                            .padding(vertical = 12.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun TrackDetailsScreen(
    track: Track,
    musicPlayer: MusicPlayer,
    onBack: () -> Unit,
    onPlay: (Track) -> Unit,
    modifier: Modifier = Modifier
) {

    var position by remember {
        mutableStateOf(0L)
    }

    var duration by remember {
        mutableStateOf(0L)
    }

    var isPlaying by remember {
        mutableStateOf(false)
    }

    LaunchedEffect(Unit) {

        while (true) {

            musicPlayer.updateProgress()

            position = musicPlayer.position.value
            duration = musicPlayer.duration.value
            isPlaying = musicPlayer.isPlaying.value

            delay(250)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {

        Button(
            onClick = onBack
        ) {
            Text("← Wróć")
        }

        Text(
            text = "Szczegóły utworu",
            modifier = Modifier.padding(top = 32.dp)
        )

        Text(
            text = track.fileName,
            modifier = Modifier.padding(top = 24.dp)
        )

        Button(
            onClick = {

                if (isPlaying) {
                    musicPlayer.togglePlayPause()
                } else {
                    onPlay(track)
                }

            },
            modifier = Modifier.padding(top = 24.dp)
        ) {

            Text(
                if (isPlaying) {
                    "⏸ Pauza"
                } else {
                    "▶ Odtwórz"
                }
            )
        }

        Slider(
            value = if (duration > 0L) {

                (
                        position.toFloat() /
                                duration.toFloat()
                        ).coerceIn(0f, 1f)

            } else {
                0f
            },

            onValueChange = { value ->

                if (duration > 0L) {

                    val newPosition =
                        (value * duration).toLong()

                    musicPlayer.seekTo(newPosition)

                    position = newPosition
                }
            },

            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Text(
                text = formatTime(position)
            )

            Text(
                text = formatTime(duration)
            )
        }
    }
}

fun formatTime(milliseconds: Long): String {

    val totalSeconds = milliseconds / 1000

    val minutes = totalSeconds / 60

    val seconds = totalSeconds % 60

    return "%d:%02d".format(
        minutes,
        seconds
    )
}