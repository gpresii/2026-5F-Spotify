package com.example.localmusic

import android.database.Cursor
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.example.localmusic.data.DatabaseProvider
import com.example.localmusic.data.Track
import com.example.localmusic.ui.theme.LocalMusicTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {

    private var tracks by mutableStateOf<List<Track>>(emptyList())

    private var selectedTrack by mutableStateOf<Track?>(null)

    private var showSettings by mutableStateOf(false)

    private var darkTheme by mutableStateOf(false)

    private val database by lazy {
        DatabaseProvider.getDatabase(
            applicationContext
        )
    }

    private val musicPlayer by lazy {
        MusicPlayer(applicationContext)
    }

    private val preferences by lazy {
        getSharedPreferences(
            "local_music_settings",
            MODE_PRIVATE
        )
    }

    private val pickAudio =
        registerForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->

            if (uri != null) {

                CoroutineScope(Dispatchers.IO).launch {

                    try {

                        val fileName =
                            getFileName(uri)

                        val alreadyExists =
                            tracks.any { track ->

                                track.fileName.equals(
                                    fileName,
                                    ignoreCase = true
                                )
                            }

                        if (alreadyExists) {

                            println(
                                "LOCALMUSIC: utwór już istnieje: $fileName"
                            )

                            return@launch
                        }

                        val musicDirectory =
                            File(
                                filesDir,
                                "music"
                            )

                        if (!musicDirectory.exists()) {
                            musicDirectory.mkdirs()
                        }

                        val safeFileName =
                            fileName
                                .replace("/", "_")
                                .replace("\\", "_")

                        val timestamp =
                            System.currentTimeMillis()

                        val destinationFile =
                            File(
                                musicDirectory,
                                "${timestamp}_$safeFileName"
                            )

                        contentResolver
                            .openInputStream(uri)
                            ?.use { input ->

                                destinationFile
                                    .outputStream()
                                    .use { output ->

                                        input.copyTo(output)
                                    }
                            }

                        if (
                            !destinationFile.exists() ||
                            destinationFile.length() == 0L
                        ) {

                            println(
                                "LOCALMUSIC ERROR: nie udało się skopiować pliku"
                            )

                            return@launch
                        }

                        val retriever =
                            MediaMetadataRetriever()

                        retriever.setDataSource(
                            destinationFile.absolutePath
                        )

                        val title =
                            retriever.extractMetadata(
                                MediaMetadataRetriever.METADATA_KEY_TITLE
                            )

                        val artist =
                            retriever.extractMetadata(
                                MediaMetadataRetriever.METADATA_KEY_ARTIST
                            )

                        val album =
                            retriever.extractMetadata(
                                MediaMetadataRetriever.METADATA_KEY_ALBUM
                            )

                        val year =
                            retriever.extractMetadata(
                                MediaMetadataRetriever.METADATA_KEY_YEAR
                            )

                        val artwork =
                            retriever.embeddedPicture

                        var artworkPath: String? = null

                        if (artwork != null) {

                            val artworkFile =
                                File(
                                    musicDirectory,
                                    "${timestamp}_cover.jpg"
                                )

                            artworkFile
                                .outputStream()
                                .use { output ->

                                    output.write(artwork)
                                }

                            artworkPath =
                                artworkFile.absolutePath
                        }

                        retriever.release()

                        val track =
                            Track(
                                fileName = fileName,
                                uri =
                                    destinationFile.absolutePath,
                                title = title,
                                artist = artist,
                                album = album,
                                year = year,
                                artworkPath =
                                    artworkPath
                            )

                        database
                            .trackDao()
                            .insertTrack(track)

                    } catch (e: Exception) {

                        e.printStackTrace()
                    }
                }
            }
        }

    private fun getFileName(
        uri: Uri
    ): String {

        var fileName =
            "Nieznany utwór"

        val cursor: Cursor? =
            contentResolver.query(
                uri,
                arrayOf(
                    OpenableColumns.DISPLAY_NAME
                ),
                null,
                null,
                null
            )

        cursor?.use {

            if (it.moveToFirst()) {

                val nameIndex =
                    it.getColumnIndex(
                        OpenableColumns.DISPLAY_NAME
                    )

                if (nameIndex >= 0) {

                    fileName =
                        it.getString(
                            nameIndex
                        )
                }
            }
        }

        return fileName
    }

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(
            savedInstanceState
        )

        darkTheme =
            preferences.getBoolean(
                "dark_theme",
                false
            )

        enableEdgeToEdge()

        CoroutineScope(Dispatchers.IO).launch {

            database
                .trackDao()
                .getAllTracks()
                .collectLatest { trackList ->

                    tracks =
                        trackList

                    selectedTrack =
                        selectedTrack?.let { current ->

                            trackList.find {
                                it.id == current.id
                            }
                        }
                }
        }

        setContent {

            LocalMusicTheme(
                darkTheme = darkTheme
            ) {

                LocalMusicApp(
                    tracks = tracks,

                    selectedTrack =
                        selectedTrack,

                    showSettings =
                        showSettings,

                    darkTheme =
                        darkTheme,

                    musicPlayer =
                        musicPlayer,

                    onTrackClick = {
                            track ->

                        selectedTrack =
                            track
                    },

                    onBack = {

                        selectedTrack =
                            null
                    },

                    onPlay = {
                            track ->

                        musicPlayer.play(
                            track.uri
                        )
                    },

                    onToggleFavorite = {
                            track ->

                        CoroutineScope(
                            Dispatchers.IO
                        ).launch {

                            database
                                .trackDao()
                                .toggleFavorite(
                                    track.id
                                )
                        }
                    },

                    onAddTrack = {

                        pickAudio.launch(
                            arrayOf(
                                "audio/mpeg"
                            )
                        )
                    },

                    onOpenSettings = {

                        showSettings =
                            true
                    },

                    onCloseSettings = {

                        showSettings =
                            false
                    },

                    onDarkThemeChanged = {
                            enabled ->

                        darkTheme =
                            enabled

                        preferences
                            .edit()
                            .putBoolean(
                                "dark_theme",
                                enabled
                            )
                            .apply()
                    },

                    onSaveMetadata = {
                            track,
                            title,
                            artist,
                            album,
                            year ->

                        CoroutineScope(
                            Dispatchers.IO
                        ).launch {

                            database
                                .trackDao()
                                .updateMetadata(
                                    id = track.id,
                                    title = title,
                                    artist = artist,
                                    album = album,
                                    year = year
                                )
                        }
                    }
                )
            }
        }
    }

    override fun onDestroy() {

        musicPlayer.release()

        super.onDestroy()
    }
}

@Composable
fun LocalMusicApp(
    tracks: List<Track>,
    selectedTrack: Track?,
    showSettings: Boolean,
    darkTheme: Boolean,
    musicPlayer: MusicPlayer,

    onTrackClick:
        (Track) -> Unit,

    onBack:
        () -> Unit,

    onPlay:
        (Track) -> Unit,

    onToggleFavorite:
        (Track) -> Unit,

    onAddTrack:
        () -> Unit,

    onOpenSettings:
        () -> Unit,

    onCloseSettings:
        () -> Unit,

    onDarkThemeChanged:
        (Boolean) -> Unit,

    onSaveMetadata:
        (
        Track,
        String?,
        String?,
        String?,
        String?
    ) -> Unit
) {

    Scaffold(
        modifier =
            Modifier.fillMaxSize()
    ) { innerPadding ->

        when {

            showSettings -> {

                SettingsScreen(
                    darkTheme =
                        darkTheme,

                    onDarkThemeChanged =
                        onDarkThemeChanged,

                    onBack =
                        onCloseSettings,

                    modifier =
                        Modifier.padding(
                            innerPadding
                        )
                )
            }

            selectedTrack == null -> {

                LibraryScreen(
                    tracks =
                        tracks,

                    onTrackClick =
                        onTrackClick,

                    onAddTrack =
                        onAddTrack,

                    onOpenSettings =
                        onOpenSettings,

                    modifier =
                        Modifier.padding(
                            innerPadding
                        )
                )
            }

            else -> {

                TrackDetailsScreen(
                    track =
                        selectedTrack,

                    musicPlayer =
                        musicPlayer,

                    onBack =
                        onBack,

                    onPlay =
                        onPlay,

                    onToggleFavorite =
                        onToggleFavorite,

                    onSaveMetadata =
                        onSaveMetadata,

                    modifier =
                        Modifier.padding(
                            innerPadding
                        )
                )
            }
        }
    }
}

@Composable
fun LibraryScreen(
    tracks: List<Track>,

    onTrackClick:
        (Track) -> Unit,

    onAddTrack:
        () -> Unit,

    onOpenSettings:
        () -> Unit,

    modifier: Modifier =
        Modifier
) {

    var showFavoritesOnly by remember {
        mutableStateOf(false)
    }

    var searchQuery by remember {
        mutableStateOf("")
    }

    val displayedTracks =
        tracks
            .filter { track ->

                if (showFavoritesOnly) {
                    track.isFavorite
                } else {
                    true
                }
            }
            .filter { track ->

                if (searchQuery.isBlank()) {
                    true
                } else {

                    val query =
                        searchQuery.trim()
                            .lowercase()

                    val title =
                        track.title
                            ?.lowercase()
                            ?: ""

                    val artist =
                        track.artist
                            ?.lowercase()
                            ?: ""

                    val album =
                        track.album
                            ?.lowercase()
                            ?: ""

                    val fileName =
                        track.fileName
                            .lowercase()

                    title.contains(query) ||
                            artist.contains(query) ||
                            album.contains(query) ||
                            fileName.contains(query)
                }
            }

    Column(
        modifier =
            modifier
                .fillMaxSize()
                .padding(24.dp)
    ) {

        Row(
            modifier =
                Modifier.fillMaxWidth(),

            horizontalArrangement =
                Arrangement.SpaceBetween,

            verticalAlignment =
                Alignment.CenterVertically
        ) {

            Text(
                text = "LocalMusic"
            )

            Row {

                Button(
                    onClick =
                        onOpenSettings
                ) {

                    Text(
                        text = "⚙"
                    )
                }

                Button(
                    onClick =
                        onAddTrack
                ) {

                    Text(
                        text = "Dodaj utwór"
                    )
                }
            }
        }

        OutlinedTextField(
            value =
                searchQuery,

            onValueChange = {
                searchQuery = it
            },

            singleLine = true,

            label = {
                Text(
                    text = "Szukaj"
                )
            },

            placeholder = {
                Text(
                    text =
                        "Tytuł, wykonawca, album..."
                )
            },

            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(
                        top = 20.dp
                    )
        )

        Row(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(
                        top = 16.dp
                    ),

            horizontalArrangement =
                Arrangement.spacedBy(
                    8.dp
                )
        ) {

            Button(
                onClick = {
                    showFavoritesOnly =
                        false
                }
            ) {

                Text(
                    text =
                        "🎵 Wszystkie"
                )
            }

            Button(
                onClick = {
                    showFavoritesOnly =
                        true
                }
            ) {

                Text(
                    text =
                        "❤️ Ulubione"
                )
            }
        }

        if (
            displayedTracks.isEmpty()
        ) {

            Text(
                text =
                    when {

                        searchQuery.isNotBlank() ->
                            "Nie znaleziono utworów."

                        showFavoritesOnly ->
                            "Nie masz jeszcze ulubionych utworów."

                        else ->
                            "Twoja biblioteka muzyczna jest pusta."
                    },

                modifier =
                    Modifier.padding(
                        top = 32.dp
                    )
            )

        } else {

            LazyColumn(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(
                            top = 24.dp
                        )
            ) {

                items(
                    displayedTracks
                ) { track ->

                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .clickable {

                                    onTrackClick(
                                        track
                                    )
                                }
                                .padding(
                                    vertical = 8.dp
                                ),

                        verticalAlignment =
                            Alignment.CenterVertically
                    ) {

                        TrackArtwork(
                            artworkPath =
                                track.artworkPath,

                            size = 64
                        )

                        Column(
                            modifier =
                                Modifier.padding(
                                    start = 12.dp
                                )
                        ) {

                            Text(
                                text =
                                    track.title
                                        ?: track.fileName
                            )

                            if (
                                track.artist != null
                            ) {

                                Text(
                                    text =
                                        track.artist
                                )
                            }

                            if (
                                track.album != null
                            ) {

                                Text(
                                    text =
                                        track.album
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    darkTheme: Boolean,

    onDarkThemeChanged:
        (Boolean) -> Unit,

    onBack:
        () -> Unit,

    modifier: Modifier =
        Modifier
) {

    Column(
        modifier =
            modifier
                .fillMaxSize()
                .padding(24.dp)
    ) {

        Button(
            onClick =
                onBack
        ) {

            Text(
                text = "← Wróć"
            )
        }

        Text(
            text = "Ustawienia",

            modifier =
                Modifier.padding(
                    top = 32.dp
                )
        )

        Row(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(
                        top = 32.dp
                    ),

            horizontalArrangement =
                Arrangement.SpaceBetween,

            verticalAlignment =
                Alignment.CenterVertically
        ) {

            Text(
                text = "Ciemny motyw"
            )

            Switch(
                checked =
                    darkTheme,

                onCheckedChange =
                    onDarkThemeChanged
            )
        }
    }
}

@Composable
fun TrackDetailsScreen(
    track: Track,
    musicPlayer: MusicPlayer,

    onBack:
        () -> Unit,

    onPlay:
        (Track) -> Unit,

    onToggleFavorite:
        (Track) -> Unit,

    onSaveMetadata:
        (
        Track,
        String?,
        String?,
        String?,
        String?
    ) -> Unit,

    modifier: Modifier =
        Modifier
) {

    var position by remember {
        mutableStateOf(0L)
    }

    var duration by remember {
        mutableStateOf(0L)
    }

    var isPlaying by remember {
        mutableStateOf(false)
    }

    var showEditDialog by remember {
        mutableStateOf(false)
    }

    Column(
        modifier =
            modifier
                .fillMaxSize()
                .padding(24.dp)
    ) {

        Button(
            onClick =
                onBack
        ) {

            Text(
                text = "← Wróć"
            )
        }

        TrackArtwork(
            artworkPath =
                track.artworkPath,

            size = 280
        )

        Spacer(
            modifier =
                Modifier.height(24.dp)
        )

        Text(
            text =
                "Szczegóły utworu"
        )

        Text(
            text =
                track.title
                    ?: track.fileName,

            modifier =
                Modifier.padding(
                    top = 16.dp
                )
        )

        Text(
            text =
                track.artist
                    ?: "Nieznany wykonawca",

            modifier =
                Modifier.padding(
                    top = 8.dp
                )
        )

        Text(
            text =
                track.album
                    ?: "Nieznany album",

            modifier =
                Modifier.padding(
                    top = 4.dp
                )
        )

        if (track.year != null) {

            Text(
                text =
                    track.year,

                modifier =
                    Modifier.padding(
                        top = 4.dp
                    )
            )
        }

        Button(
            onClick = {

                onToggleFavorite(
                    track
                )
            },

            modifier =
                Modifier.padding(
                    top = 16.dp
                )
        ) {

            Text(
                text =
                    if (
                        track.isFavorite
                    ) {

                        "❤️ Usuń z ulubionych"

                    } else {

                        "♡ Dodaj do ulubionych"
                    }
            )
        }

        Button(
            onClick = {

                if (isPlaying) {

                    musicPlayer
                        .togglePlayPause()

                } else {

                    onPlay(track)
                }
            },

            modifier =
                Modifier.padding(
                    top = 8.dp
                )
        ) {

            Text(
                text =
                    if (isPlaying) {
                        "⏸ Pauza"
                    } else {
                        "▶ Odtwórz"
                    }
            )
        }

        Button(
            onClick = {
                showEditDialog =
                    true
            },

            modifier =
                Modifier.padding(
                    top = 8.dp
                )
        ) {

            Text(
                text = "✏️ Edytuj"
            )
        }

        LaunchedEffect(Unit) {

            while (true) {

                musicPlayer
                    .updateProgress()

                position =
                    musicPlayer
                        .position
                        .value

                duration =
                    musicPlayer
                        .duration
                        .value

                isPlaying =
                    musicPlayer
                        .isPlaying
                        .value

                delay(250)
            }
        }

        Slider(
            value =
                if (duration > 0L) {

                    (
                            position.toFloat() /
                                    duration.toFloat()
                            ).coerceIn(
                            0f,
                            1f
                        )

                } else {

                    0f
                },

            onValueChange = {
                    value ->

                if (duration > 0L) {

                    val newPosition =
                        (
                                value * duration
                                ).toLong()

                    musicPlayer.seekTo(
                        newPosition
                    )

                    position =
                        newPosition
                }
            },

            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(
                        top = 16.dp
                    )
        )

        Row(
            modifier =
                Modifier.fillMaxWidth(),

            horizontalArrangement =
                Arrangement.SpaceBetween
        ) {

            Text(
                text =
                    formatTime(
                        position
                    )
            )

            Text(
                text =
                    formatTime(
                        duration
                    )
            )
        }
    }

    if (showEditDialog) {

        EditMetadataDialog(
            track =
                track,

            onDismiss = {
                showEditDialog =
                    false
            },

            onSave = {
                    title,
                    artist,
                    album,
                    year ->

                onSaveMetadata(
                    track,
                    title,
                    artist,
                    album,
                    year
                )

                showEditDialog =
                    false
            }
        )
    }
}

@Composable
fun EditMetadataDialog(
    track: Track,

    onDismiss:
        () -> Unit,

    onSave:
        (
        String?,
        String?,
        String?,
        String?
    ) -> Unit
) {

    var title by remember {
        mutableStateOf("")
    }

    var artist by remember {
        mutableStateOf("")
    }

    var album by remember {
        mutableStateOf("")
    }

    var year by remember {
        mutableStateOf("")
    }

    AlertDialog(
        onDismissRequest =
            onDismiss,

        title = {

            Text(
                text = "Edytuj utwór"
            )
        },

        text = {

            Column {

                OutlinedTextField(
                    value = title,

                    onValueChange = {
                        title = it
                    },

                    placeholder = {

                        Text(
                            text =
                                track.title
                                    ?: "Brak tytułu"
                        )
                    },

                    label = {

                        Text(
                            text = "Tytuł"
                        )
                    },

                    singleLine = true,

                    modifier =
                        Modifier.fillMaxWidth()
                )

                Spacer(
                    modifier =
                        Modifier.height(8.dp)
                )

                OutlinedTextField(
                    value = artist,

                    onValueChange = {
                        artist = it
                    },

                    placeholder = {

                        Text(
                            text =
                                track.artist
                                    ?: "Brak wykonawcy"
                        )
                    },

                    label = {

                        Text(
                            text = "Wykonawca"
                        )
                    },

                    singleLine = true,

                    modifier =
                        Modifier.fillMaxWidth()
                )

                Spacer(
                    modifier =
                        Modifier.height(8.dp)
                )

                OutlinedTextField(
                    value = album,

                    onValueChange = {
                        album = it
                    },

                    placeholder = {

                        Text(
                            text =
                                track.album
                                    ?: "Brak albumu"
                        )
                    },

                    label = {

                        Text(
                            text = "Album"
                        )
                    },

                    singleLine = true,

                    modifier =
                        Modifier.fillMaxWidth()
                )

                Spacer(
                    modifier =
                        Modifier.height(8.dp)
                )

                OutlinedTextField(
                    value = year,

                    onValueChange = {
                        year = it
                    },

                    placeholder = {

                        Text(
                            text =
                                track.year
                                    ?: "Brak roku"
                        )
                    },

                    label = {

                        Text(
                            text = "Rok"
                        )
                    },

                    singleLine = true,

                    modifier =
                        Modifier.fillMaxWidth()
                )
            }
        },

        confirmButton = {

            Button(
                onClick = {

                    onSave(

                        if (
                            title.isBlank()
                        ) {
                            track.title
                        } else {
                            title.trim()
                        },

                        if (
                            artist.isBlank()
                        ) {
                            track.artist
                        } else {
                            artist.trim()
                        },

                        if (
                            album.isBlank()
                        ) {
                            track.album
                        } else {
                            album.trim()
                        },

                        if (
                            year.isBlank()
                        ) {
                            track.year
                        } else {
                            year.trim()
                        }
                    )
                }
            ) {

                Text(
                    text = "Zapisz"
                )
            }
        },

        dismissButton = {

            TextButton(
                onClick =
                    onDismiss
            ) {

                Text(
                    text = "Anuluj"
                )
            }
        }
    )
}

@Composable
fun TrackArtwork(
    artworkPath: String?,
    size: Int
) {

    val bitmap =
        remember(artworkPath) {

            if (
                !artworkPath.isNullOrBlank()
            ) {

                val file =
                    File(artworkPath)

                if (
                    file.exists() &&
                    file.length() > 0L
                ) {

                    BitmapFactory
                        .decodeFile(
                            file.absolutePath
                        )

                } else {

                    null
                }

            } else {

                null
            }
        }

    if (bitmap != null) {

        Image(
            bitmap =
                bitmap.asImageBitmap(),

            contentDescription =
                "Okładka utworu",

            contentScale =
                ContentScale.Crop,

            modifier =
                Modifier
                    .size(
                        size.dp
                    )
                    .clip(
                        RoundedCornerShape(
                            12.dp
                        )
                    )
        )

    } else {

        Column(
            modifier =
                Modifier
                    .size(
                        size.dp
                    )
                    .clip(
                        RoundedCornerShape(
                            12.dp
                        )
                    ),

            horizontalAlignment =
                Alignment.CenterHorizontally,

            verticalArrangement =
                Arrangement.Center
        ) {

            Text(
                text = "🎵"
            )

            Text(
                text = "Brak okładki"
            )
        }
    }
}

fun formatTime(
    milliseconds: Long
): String {

    val totalSeconds =
        milliseconds / 1000

    val minutes =
        totalSeconds / 60

    val seconds =
        totalSeconds % 60

    return "%d:%02d".format(
        minutes,
        seconds
    )
}