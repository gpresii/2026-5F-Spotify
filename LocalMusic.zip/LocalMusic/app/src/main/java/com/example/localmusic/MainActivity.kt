
package com.example.localmusic

import android.database.Cursor
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localmusic.data.DatabaseProvider
import com.example.localmusic.data.Playlist
import com.example.localmusic.data.Track
import com.example.localmusic.data.dao.PlaylistDao
import com.example.localmusic.ui.theme.LocalMusicTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File

private enum class AppTab(val label: String, val symbol: String) {
    LIBRARY("Biblioteka", "♫"),
    QUEUE("Kolejka", "☷"),
    PLAYLISTS("Playlisty", "▤"),
    FAVORITES("Ulubione", "♥"),
    SETTINGS("Ustawienia", "⚙")
}

private val PlayerBackground = Color(0xFF101016)
private val PlayerSurface = Color(0xFF1B1B25)
private val PlayerAccent = Color(0xFFB9A4FF)
private val PlayerText = Color(0xFFF5F3FA)
private val PlayerMuted = Color(0xFFA6A3B5)

class MainActivity : ComponentActivity() {

    private var tracks by mutableStateOf<List<Track>>(emptyList())
    private var playlists by mutableStateOf<List<Playlist>>(emptyList())
    private var selectedTrack by mutableStateOf<Track?>(null)
    private var selectedPlaylistId by mutableStateOf<Int?>(null)
    private var darkTheme by mutableStateOf(false)

    private val database by lazy {
        DatabaseProvider.getDatabase(applicationContext)
    }

    private val musicPlayer by lazy {
        MusicPlayer(applicationContext)
    }

    private val preferences by lazy {
        getSharedPreferences("local_music_settings", MODE_PRIVATE)
    }

    private val pickAudio =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                CoroutineScope(Dispatchers.IO).launch {
                    var destinationFile: File? = null
                    var retriever: MediaMetadataRetriever? = null

                    try {
                        val fileName = getFileName(uri)

                        if (tracks.any {
                                it.fileName.equals(fileName, ignoreCase = true)
                            }
                        ) {
                            showMessage("Ten utwór jest już w bibliotece.")
                            return@launch
                        }

                        val musicDirectory = File(filesDir, "music")
                        if (!musicDirectory.exists()) musicDirectory.mkdirs()

                        val safeFileName = fileName
                            .replace("/", "_")
                            .replace("\\", "_")

                        val timestamp = System.currentTimeMillis()
                        destinationFile = File(
                            musicDirectory,
                            "${timestamp}_$safeFileName"
                        )

                        val inputStream = contentResolver.openInputStream(uri)
                        if (inputStream == null) {
                            showMessage("Nie można otworzyć wybranego pliku.")
                            return@launch
                        }

                        inputStream.use { input ->
                            destinationFile.outputStream().use { output ->
                                input.copyTo(output)
                            }
                        }

                        if (destinationFile.length() == 0L) {
                            destinationFile.delete()
                            showMessage("Wybrany plik jest pusty.")
                            return@launch
                        }

                        retriever = MediaMetadataRetriever()
                        retriever.setDataSource(destinationFile.absolutePath)

                        val title = retriever.extractMetadata(
                            MediaMetadataRetriever.METADATA_KEY_TITLE
                        )
                        val artist = retriever.extractMetadata(
                            MediaMetadataRetriever.METADATA_KEY_ARTIST
                        )
                        val album = retriever.extractMetadata(
                            MediaMetadataRetriever.METADATA_KEY_ALBUM
                        )
                        val year = retriever.extractMetadata(
                            MediaMetadataRetriever.METADATA_KEY_YEAR
                        )
                        val artwork = retriever.embeddedPicture

                        var artworkPath: String? = null

                        if (artwork != null) {
                            val artworkFile = File(
                                musicDirectory,
                                "${timestamp}_cover.jpg"
                            )
                            artworkFile.outputStream().use { it.write(artwork) }
                            artworkPath = artworkFile.absolutePath
                        }

                        retriever.release()
                        retriever = null

                        database.trackDao().insertTrack(
                            Track(
                                fileName = fileName,
                                uri = destinationFile.absolutePath,
                                title = title,
                                artist = artist,
                                album = album,
                                year = year,
                                artworkPath = artworkPath
                            )
                        )

                        showMessage("Dodano utwór: $fileName")
                    } catch (e: Exception) {
                        e.printStackTrace()
                        destinationFile?.delete()
                        showMessage(
                            "Błąd importu: ${e.message ?: e.javaClass.simpleName}"
                        )
                    } finally {
                        try {
                            retriever?.release()
                        } catch (_: Exception) {
                        }
                    }
                }
            }
        }

    private fun showMessage(message: String) {
        runOnUiThread {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    private fun getFileName(uri: Uri): String {
        var fileName = "Nieznany utwór"

        val cursor: Cursor? = contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )

        cursor?.use {
            if (it.moveToFirst()) {
                val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) fileName = it.getString(index)
            }
        }

        return fileName
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        darkTheme = preferences.getBoolean("dark_theme", false)
        enableEdgeToEdge()

        CoroutineScope(Dispatchers.IO).launch {
            database.trackDao().getAllTracks().collectLatest { list ->
                tracks = list
                selectedTrack = selectedTrack?.let { current ->
                    list.find { it.id == current.id }
                }
            }
        }

        CoroutineScope(Dispatchers.IO).launch {
            database.playlistDao().getAllPlaylists().collectLatest {
                playlists = it
            }
        }

        setContent {
            LocalMusicTheme(darkTheme = darkTheme) {
                LocalMusicApp(
                    tracks = tracks,
                    playlists = playlists,
                    playlistDao = database.playlistDao(),
                    selectedTrack = selectedTrack,
                    selectedPlaylistId = selectedPlaylistId,
                    darkTheme = darkTheme,
                    musicPlayer = musicPlayer,
                    onTrackClick = { selectedTrack = it },
                    onBackFromTrack = { selectedTrack = null },
                    onPlay = { musicPlayer.play(it.uri) },
                    onToggleFavorite = { track ->
                        CoroutineScope(Dispatchers.IO).launch {
                            database.trackDao().toggleFavorite(track.id)
                        }
                    },
                    onAddTrack = {
                        pickAudio.launch(arrayOf("audio/*"))
                    },
                    onDarkThemeChanged = { enabled ->
                        darkTheme = enabled
                        preferences.edit()
                            .putBoolean("dark_theme", enabled)
                            .apply()
                    },
                    onSaveMetadata = { track, title, artist, album, year ->
                        CoroutineScope(Dispatchers.IO).launch {
                            database.trackDao().updateMetadata(
                                id = track.id,
                                title = title,
                                artist = artist,
                                album = album,
                                year = year
                            )
                        }
                    },
                    onCreatePlaylist = { name ->
                        CoroutineScope(Dispatchers.IO).launch {
                            database.playlistDao().insertPlaylist(
                                Playlist(name = name)
                            )
                        }
                    },
                    onOpenPlaylist = { id ->
                        selectedPlaylistId = id
                    },
                    onBackFromPlaylist = {
                        selectedPlaylistId = null
                    },
                    onDeletePlaylist = { id ->
                        CoroutineScope(Dispatchers.IO).launch {
                            database.playlistDao().removeAllTracksFromPlaylist(id)
                            database.playlistDao().deletePlaylist(id)
                        }

                        if (selectedPlaylistId == id) {
                            selectedPlaylistId = null
                        }
                    },
                    onAddTrackToPlaylist = { playlistId, trackId ->
                        CoroutineScope(Dispatchers.IO).launch {
                            database.playlistDao().addTrackToPlaylist(
                                com.example.localmusic.data.PlaylistTrack(
                                    playlistId = playlistId,
                                    trackId = trackId
                                )
                            )
                        }
                    },
                    onRemoveTrackFromPlaylist = { playlistId, trackId ->
                        CoroutineScope(Dispatchers.IO).launch {
                            database.playlistDao().removeTrackFromPlaylist(
                                playlistId,
                                trackId
                            )
                        }
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        musicPlayer.release()
        super.onDestroy()
    }
}

@Composable
fun LocalMusicApp(
    tracks: List<Track>,
    playlists: List<Playlist>,
    playlistDao: PlaylistDao,
    selectedTrack: Track?,
    selectedPlaylistId: Int?,
    darkTheme: Boolean,
    musicPlayer: MusicPlayer,
    onTrackClick: (Track) -> Unit,
    onBackFromTrack: () -> Unit,
    onPlay: (Track) -> Unit,
    onToggleFavorite: (Track) -> Unit,
    onAddTrack: () -> Unit,
    onDarkThemeChanged: (Boolean) -> Unit,
    onSaveMetadata: (Track, String?, String?, String?, String?) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onOpenPlaylist: (Int) -> Unit,
    onBackFromPlaylist: () -> Unit,
    onDeletePlaylist: (Int) -> Unit,
    onAddTrackToPlaylist: (Int, Int) -> Unit,
    onRemoveTrackFromPlaylist: (Int, Int) -> Unit
) {
    var currentTab by remember { mutableStateOf(AppTab.LIBRARY) }
    var playlistTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var activeQueue by remember { mutableStateOf<List<Track>>(emptyList()) }

    val currentPath by musicPlayer.currentPath.collectAsState()
    val miniPlayerIsPlaying by musicPlayer.isPlaying.collectAsState()
    val queuePaths by musicPlayer.queue.collectAsState()

    val currentTrack = tracks.find { it.uri == currentPath }

    fun playFromQueue(queue: List<Track>, track: Track) {
        val index = queue.indexOfFirst { it.id == track.id }

        if (index >= 0) {
            activeQueue = queue
            musicPlayer.playQueue(queue.map { it.uri }, index)
        } else {
            activeQueue = listOf(track)
            musicPlayer.play(track.uri)
        }
    }

    LaunchedEffect(currentPath, tracks, selectedTrack) {
        if (selectedTrack != null) {
            val playingTrack = tracks.find { it.uri == currentPath }

            if (playingTrack != null && playingTrack.id != selectedTrack.id) {
                onTrackClick(playingTrack)
            }
        }
    }

    LaunchedEffect(selectedPlaylistId) {
        if (selectedPlaylistId == null) {
            playlistTracks = emptyList()
        } else {
            playlistDao.getTracksInPlaylist(selectedPlaylistId).collectLatest {
                playlistTracks = it
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (selectedTrack == null) {
                Column {
                    if (currentTrack != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(PlayerSurface)
                                .clickable { onTrackClick(currentTrack) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TrackArtwork(
                                artworkPath = currentTrack.artworkPath,
                                size = 44
                            )

                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(start = 10.dp)
                            ) {
                                Text(
                                    currentTrack.title ?: currentTrack.fileName,
                                    color = PlayerText,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Text(
                                    currentTrack.artist ?: "Nieznany wykonawca",
                                    color = PlayerMuted,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            IconButton(
                                onClick = { musicPlayer.togglePlayPause() }
                            ) {
                                Text(
                                    if (miniPlayerIsPlaying) "Ⅱ" else "▶",
                                    color = PlayerAccent,
                                    fontSize = 22.sp
                                )
                            }
                        }
                    }

                    NavigationBar {
                        AppTab.entries.forEach { tab ->
                            NavigationBarItem(
                                selected = currentTab == tab,
                                onClick = {
                                    currentTab = tab

                                    if (selectedPlaylistId != null) {
                                        onBackFromPlaylist()
                                    }
                                },
                                icon = {
                                    Text(
                                        text = tab.symbol,
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                },
                                label = { Text(tab.label) },
                                alwaysShowLabel = true
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                selectedTrack != null -> {
                    TrackDetailsScreen(
                        track = selectedTrack,
                        musicPlayer = musicPlayer,
                        onBack = onBackFromTrack,
                        onPlay = { track ->
                            val queue = activeQueue.ifEmpty { tracks }
                            playFromQueue(queue, track)
                        },
                        onToggleFavorite = onToggleFavorite,
                        onSaveMetadata = onSaveMetadata,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                currentTab == AppTab.QUEUE -> {
                    QueueScreen(
                        queuePaths = queuePaths,
                        tracks = tracks,
                        currentPath = currentPath,
                        onPlay = { index ->
                            musicPlayer.playQueueItem(index)

                            tracks.find {
                                it.uri == queuePaths.getOrNull(index)
                            }?.let { onTrackClick(it) }
                        },
                        onRemove = { index ->
                            musicPlayer.removeFromQueue(index)
                        },
                        onMove = { from, to ->
                            musicPlayer.moveQueueItem(from, to)
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                currentTab == AppTab.LIBRARY -> {
                    LibraryScreen(
                        tracks = tracks,
                        onTrackClick = { track ->
                            playFromQueue(tracks, track)
                            onTrackClick(track)
                        },
                        onAddTrack = onAddTrack,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                currentTab == AppTab.FAVORITES -> {
                    val favoriteTracks = tracks.filter { it.isFavorite }

                    TrackListScreen(
                        title = "Ulubione",
                        tracks = favoriteTracks,
                        emptyMessage = "Nie masz jeszcze ulubionych utworów.",
                        onTrackClick = { track ->
                            playFromQueue(favoriteTracks, track)
                            onTrackClick(track)
                        },
                        onPlay = { track ->
                            playFromQueue(favoriteTracks, track)
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                currentTab == AppTab.PLAYLISTS -> {
                    PlaylistScreen(
                        playlists = playlists,
                        allTracks = tracks,
                        selectedPlaylistId = selectedPlaylistId,
                        playlistTracks = playlistTracks,
                        onCreatePlaylist = onCreatePlaylist,
                        onOpenPlaylist = onOpenPlaylist,
                        onBack = onBackFromPlaylist,
                        onDeletePlaylist = onDeletePlaylist,
                        onAddTrack = onAddTrackToPlaylist,
                        onRemoveTrack = onRemoveTrackFromPlaylist,
                        onTrackClick = { track ->
                            playFromQueue(playlistTracks, track)
                            onTrackClick(track)
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                currentTab == AppTab.SETTINGS -> {
                    SettingsScreen(
                        darkTheme = darkTheme,
                        onDarkThemeChanged = onDarkThemeChanged,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

@Composable
fun QueueScreen(
    queuePaths: List<String>,
    tracks: List<Track>,
    currentPath: String?,
    onPlay: (Int) -> Unit,
    onRemove: (Int) -> Unit,
    onMove: (Int, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            text = "Kolejka odtwarzania",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)
        )

        Text(
            text = "${queuePaths.size} utworów",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        if (queuePaths.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 48.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("♫", fontSize = 48.sp, color = PlayerAccent)

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        "Kolejka jest pusta",
                        style = MaterialTheme.typography.titleLarge
                    )

                    Text(
                        "Włącz utwór z biblioteki, aby dodać muzykę.",
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(4.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(
                    items = queuePaths,
                    key = { path -> path }
                ) { path ->
                    val index = queuePaths.indexOf(path)
                    val track = tracks.find { it.uri == path }
                    val isCurrent = path == currentPath

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isCurrent) {
                                PlayerSurface
                            } else {
                                MaterialTheme.colorScheme.surface
                            }
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TrackArtwork(
                                artworkPath = track?.artworkPath,
                                size = 48
                            )

                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onPlay(index) }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = track?.title
                                        ?: track?.fileName
                                        ?: File(path).name,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontWeight = if (isCurrent) {
                                        FontWeight.Bold
                                    } else {
                                        FontWeight.Normal
                                    },
                                    color = if (isCurrent) {
                                        PlayerAccent
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    }
                                )

                                Text(
                                    text = when {
                                        isCurrent -> "Teraz odtwarzane"
                                        track?.artist != null -> track.artist
                                        else -> "Nieznany wykonawca"
                                    },
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                IconButton(
                                    onClick = { onMove(index, index - 1) },
                                    enabled = index > 0
                                ) {
                                    Text("↑")
                                }

                                IconButton(
                                    onClick = { onMove(index, index + 1) },
                                    enabled = index < queuePaths.lastIndex
                                ) {
                                    Text("↓")
                                }
                            }

                            IconButton(onClick = { onRemove(index) }) {
                                Text(
                                    "×",
                                    fontSize = 24.sp,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LibraryScreen(
    tracks: List<Track>,
    onTrackClick: (Track) -> Unit,
    onAddTrack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }

    val displayedTracks = tracks.filter { track ->
        val query = searchQuery.trim().lowercase()

        query.isBlank() ||
                (track.title ?: "").lowercase().contains(query) ||
                (track.artist ?: "").lowercase().contains(query) ||
                (track.album ?: "").lowercase().contains(query) ||
                track.fileName.lowercase().contains(query)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("LocalMusic", style = MaterialTheme.typography.headlineMedium)

            Button(onClick = onAddTrack) {
                Text("+ Dodaj")
            }
        }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            singleLine = true,
            label = { Text("Szukaj muzyki") },
            placeholder = { Text("Tytuł, wykonawca, album...") },
            modifier = Modifier.fillMaxWidth()
        )

        if (displayedTracks.isEmpty()) {
            Text(
                if (searchQuery.isBlank()) {
                    "Twoja biblioteka jest pusta. Dodaj swój pierwszy utwór."
                } else {
                    "Nie znaleziono utworów."
                },
                modifier = Modifier.padding(top = 24.dp)
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(displayedTracks, key = { it.id }) { track ->
                    TrackRow(
                        track = track,
                        onClick = { onTrackClick(track) }
                    )
                }
            }
        }
    }
}

@Composable
fun TrackListScreen(
    title: String,
    tracks: List<Track>,
    emptyMessage: String,
    onTrackClick: (Track) -> Unit,
    onPlay: (Track) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            title,
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(vertical = 16.dp)
        )

        if (tracks.isEmpty()) {
            Text(emptyMessage, modifier = Modifier.padding(top = 12.dp))
        } else {
            LazyColumn {
                items(tracks, key = { it.id }) { track ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.weight(1f)) {
                            TrackRow(
                                track = track,
                                onClick = { onTrackClick(track) }
                            )
                        }

                        TextButton(onClick = { onPlay(track) }) {
                            Text("▶")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistScreen(
    playlists: List<Playlist>,
    allTracks: List<Track>,
    selectedPlaylistId: Int?,
    playlistTracks: List<Track>,
    onCreatePlaylist: (String) -> Unit,
    onOpenPlaylist: (Int) -> Unit,
    onBack: () -> Unit,
    onDeletePlaylist: (Int) -> Unit,
    onAddTrack: (Int, Int) -> Unit,
    onRemoveTrack: (Int, Int) -> Unit,
    onTrackClick: (Track) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var showAddTrackDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }

    val selectedPlaylist = playlists.find { it.id == selectedPlaylistId }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                selectedPlaylist?.name ?: "Playlisty",
                style = MaterialTheme.typography.headlineMedium
            )

            if (selectedPlaylistId == null) {
                Button(onClick = { showCreateDialog = true }) {
                    Text("+ Nowa")
                }
            } else {
                TextButton(onClick = onBack) {
                    Text("← Playlisty")
                }
            }
        }

        if (selectedPlaylistId == null) {
            if (playlists.isEmpty()) {
                Text(
                    "Nie masz jeszcze playlist. Utwórz pierwszą przyciskiem „+ Nowa”.",
                    modifier = Modifier.padding(top = 12.dp)
                )
            } else {
                LazyColumn {
                    items(playlists, key = { it.id }) { playlist ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            onOpenPlaylist(playlist.id)
                                        }
                                        .padding(vertical = 8.dp)
                                ) {
                                    Text(
                                        playlist.name,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        "Otwórz playlistę",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                TextButton(
                                    onClick = { onDeletePlaylist(playlist.id) }
                                ) {
                                    Text("Usuń")
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(onClick = { showAddTrackDialog = true }) {
                    Text("+ Dodaj utwór")
                }
            }

            if (playlistTracks.isEmpty()) {
                Text(
                    "Ta playlista jest pusta. Dodaj do niej utwory.",
                    modifier = Modifier.padding(top = 16.dp)
                )
            } else {
                LazyColumn {
                    items(playlistTracks, key = { it.id }) { track ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.weight(1f)) {
                                TrackRow(
                                    track = track,
                                    onClick = { onTrackClick(track) }
                                )
                            }

                            TextButton(
                                onClick = {
                                    onRemoveTrack(selectedPlaylistId, track.id)
                                }
                            ) {
                                Text("Usuń")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Nowa playlista") },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    label = { Text("Nazwa playlisty") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val name = newPlaylistName.trim()
                        if (name.isNotEmpty()) {
                            onCreatePlaylist(name)
                            newPlaylistName = ""
                            showCreateDialog = false
                        }
                    }
                ) {
                    Text("Utwórz")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Anuluj")
                }
            }
        )
    }

    if (showAddTrackDialog && selectedPlaylistId != null) {
        val availableTracks = allTracks.filter { track ->
            playlistTracks.none { it.id == track.id }
        }

        AlertDialog(
            onDismissRequest = { showAddTrackDialog = false },
            title = { Text("Dodaj utwór") },
            text = {
                if (availableTracks.isEmpty()) {
                    Text("Nie ma innych utworów do dodania.")
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 350.dp)) {
                        items(availableTracks, key = { it.id }) { track ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 5.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TrackArtwork(track.artworkPath, 52)

                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(start = 10.dp)
                                ) {
                                    Text(
                                        track.title ?: track.fileName,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        track.artist ?: "Nieznany wykonawca",
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                TextButton(
                                    onClick = {
                                        onAddTrack(selectedPlaylistId, track.id)
                                    }
                                ) {
                                    Text("+", style = MaterialTheme.typography.titleLarge)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddTrackDialog = false }) {
                    Text("Gotowe")
                }
            }
        )
    }
}

@Composable
fun TrackRow(
    track: Track,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TrackArtwork(track.artworkPath, 56)

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 12.dp)
        ) {
            Text(
                track.title ?: track.fileName,
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                track.artist ?: "Nieznany wykonawca",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (track.album != null) {
                Text(track.album, style = MaterialTheme.typography.bodySmall)
            }
        }

        if (track.isFavorite) {
            Text("♥", color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun SettingsScreen(
    darkTheme: Boolean,
    onDarkThemeChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text("Ustawienia", style = MaterialTheme.typography.headlineMedium)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 28.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Ciemny motyw")
            Switch(
                checked = darkTheme,
                onCheckedChange = onDarkThemeChanged
            )
        }
    }
}

@Composable
fun TrackDetailsScreen(
    track: Track,
    musicPlayer: MusicPlayer,
    onBack: () -> Unit,
    onPlay: (Track) -> Unit,
    onToggleFavorite: (Track) -> Unit,
    onSaveMetadata: (Track, String?, String?, String?, String?) -> Unit,
    modifier: Modifier = Modifier
) {
    var position by remember(track.id) { mutableLongStateOf(0L) }
    var duration by remember(track.id) { mutableLongStateOf(0L) }
    var isPlaying by remember { mutableStateOf(false) }
    var sliderPosition by remember(track.id) { mutableFloatStateOf(0f) }
    var isDraggingSlider by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }

    LaunchedEffect(track.id) {
        while (true) {
            musicPlayer.updateProgress()
            position = musicPlayer.position.value
            duration = musicPlayer.duration.value
            isPlaying = musicPlayer.isPlaying.value

            if (!isDraggingSlider) {
                sliderPosition = if (duration > 0L) {
                    (position.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                } else {
                    0f
                }
            }

            delay(250)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PlayerBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 8.dp, bottom = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Text("⌄", fontSize = 30.sp, color = PlayerText)
            }

            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "LOCALMUSIC",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = PlayerAccent,
                    letterSpacing = 2.sp
                )
                Text(
                    "TERAZ ODTWARZANE",
                    fontSize = 10.sp,
                    color = PlayerMuted,
                    letterSpacing = 1.5.sp
                )
            }

            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .clickable { showEditDialog = true },
                contentAlignment = Alignment.Center
            ) {
                Text("⋯", fontSize = 28.sp, color = PlayerText)
            }
        }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp, bottom = 28.dp),
            contentAlignment = Alignment.Center
        ) {
            val artworkSize = maxWidth.value.toInt().coerceAtMost(360)

            Box(
                modifier = Modifier
                    .size(artworkSize.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(PlayerSurface),
                contentAlignment = Alignment.Center
            ) {
                TrackArtwork(
                    artworkPath = track.artworkPath,
                    size = artworkSize
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    track.title ?: track.fileName,
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Bold,
                    color = PlayerText,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    track.artist ?: "Nieznany wykonawca",
                    fontSize = 15.sp,
                    color = PlayerMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    track.album ?: "Nieznany album",
                    fontSize = 12.sp,
                    color = PlayerMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .clickable { onToggleFavorite(track) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (track.isFavorite) "♥" else "♡",
                    fontSize = 29.sp,
                    color = PlayerAccent
                )
            }
        }

        Spacer(modifier = Modifier.height(26.dp))

        Slider(
            value = sliderPosition,
            onValueChange = { value ->
                isDraggingSlider = true
                sliderPosition = value
            },
            onValueChangeFinished = {
                if (duration > 0L) {
                    val newPosition = (sliderPosition * duration).toLong()
                    musicPlayer.seekTo(newPosition)
                    position = newPosition
                }
                isDraggingSlider = false
            },
            colors = SliderDefaults.colors(
                thumbColor = PlayerAccent,
                activeTrackColor = PlayerAccent,
                inactiveTrackColor = Color(0xFF383744)
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(formatTime(position), color = PlayerMuted, fontSize = 12.sp)
            Text(formatTime(duration), color = PlayerMuted, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(CircleShape)
                    .clickable { musicPlayer.skipToPrevious() },
                contentAlignment = Alignment.Center
            ) {
                Text("⏮", fontSize = 25.sp, color = PlayerMuted)
            }

            Spacer(modifier = Modifier.width(26.dp))

            Box(
                modifier = Modifier
                    .size(78.dp)
                    .clip(CircleShape)
                    .background(PlayerAccent)
                    .clickable {
                        if (isPlaying) {
                            musicPlayer.togglePlayPause()
                        } else {
                            onPlay(track)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (isPlaying) "Ⅱ" else "▶",
                    fontSize = if (isPlaying) 31.sp else 27.sp,
                    fontWeight = FontWeight.Bold,
                    color = PlayerBackground
                )
            }

            Spacer(modifier = Modifier.width(26.dp))

            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(CircleShape)
                    .clickable { musicPlayer.skipToNext() },
                contentAlignment = Alignment.Center
            ) {
                Text("⏭", fontSize = 25.sp, color = PlayerMuted)
            }
        }

        Spacer(modifier = Modifier.height(26.dp))

        if (track.year != null) {
            Text(
                "Rok wydania: ${track.year}",
                color = PlayerMuted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }

        OutlinedButton(
            onClick = { showEditDialog = true },
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = PlayerAccent
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 14.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text("Edytuj informacje o utworze")
        }
    }

    if (showEditDialog) {
        EditMetadataDialog(
            track = track,
            onDismiss = { showEditDialog = false },
            onSave = { title, artist, album, year ->
                onSaveMetadata(track, title, artist, album, year)
                showEditDialog = false
            }
        )
    }
}

@Composable
fun EditMetadataDialog(
    track: Track,
    onDismiss: () -> Unit,
    onSave: (String?, String?, String?, String?) -> Unit
) {
    var title by remember(track.id) { mutableStateOf(track.title.orEmpty()) }
    var artist by remember(track.id) { mutableStateOf(track.artist.orEmpty()) }
    var album by remember(track.id) { mutableStateOf(track.album.orEmpty()) }
    var year by remember(track.id) { mutableStateOf(track.year.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edytuj utwór") },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 400.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Tytuł") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = artist,
                    onValueChange = { artist = it },
                    label = { Text("Wykonawca") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = album,
                    onValueChange = { album = it },
                    label = { Text("Album") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = year,
                    onValueChange = { year = it },
                    label = { Text("Rok") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        title.trim().ifBlank { null },
                        artist.trim().ifBlank { null },
                        album.trim().ifBlank { null },
                        year.trim().ifBlank { null }
                    )
                }
            ) {
                Text("Zapisz")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Anuluj")
            }
        }
    )
}

@Composable
fun TrackArtwork(
    artworkPath: String?,
    size: Int
) {
    val bitmap = remember(artworkPath) {
        if (!artworkPath.isNullOrBlank()) {
            val file = File(artworkPath)

            if (file.exists() && file.length() > 0L) {
                BitmapFactory.decodeFile(file.absolutePath)
            } else {
                null
            }
        } else {
            null
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Okładka utworu",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(size.dp)
                .clip(RoundedCornerShape(12.dp))
        )
    } else {
        Surface(
            modifier = Modifier
                .size(size.dp)
                .clip(RoundedCornerShape(12.dp)),
            color = Color(0xFF292735)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    "♫",
                    style = MaterialTheme.typography.headlineLarge,
                    color = PlayerAccent
                )
            }
        }
    }
}

fun formatTime(milliseconds: Long): String {
    val totalSeconds = milliseconds.coerceAtLeast(0L) / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
