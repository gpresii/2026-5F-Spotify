package com.example.localmusic.data

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.localmusic.data.dao.TrackDao

@Database(
    entities = [Track::class],
    version = 1,
    exportSchema = false
)
abstract class LocalMusicDatabase : RoomDatabase() {

    abstract fun trackDao(): TrackDao
}