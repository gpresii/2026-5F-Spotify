package com.example.localmusic.data

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.localmusic.data.dao.PlaylistDao
import com.example.localmusic.data.dao.TrackDao

@Database(
    entities = [
        Track::class,
        Playlist::class,
        PlaylistTrack::class
    ],
    version = 4,
    exportSchema = false
)
abstract class LocalMusicDatabase : RoomDatabase() {

    abstract fun trackDao(): TrackDao

    abstract fun playlistDao(): PlaylistDao
}